package net.edoxile.bettermechanics;

/**
 * Created by IntelliJ IDEA.
 * User: Edoxile
 */
public enum MechanicsType {
    GATE, SMALL_GATE, BRIDGE, SMALL_BRIDGE, LIFT, TELELIFT, DOOR, SMALL_DOOR, HIDDEN_SWITCH
}
