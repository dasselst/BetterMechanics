package net.edoxile.bettermechanics.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: Edoxile
 */
public class OutOfSpaceException extends Exception {
}
