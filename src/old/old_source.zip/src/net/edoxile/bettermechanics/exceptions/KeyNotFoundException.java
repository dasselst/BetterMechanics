package net.edoxile.bettermechanics.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: Edoxile
 */
public class KeyNotFoundException extends Exception {
}
